% SMTR Estimate the probabilities of duplications of different lengths and
% substitutions for a given sequence.
%   USAGE 1:
%   [q_hat, n_hat, period, resnorm] = SMTR(s) estmiates the distribution
%   for the mutations in s, where
%       q_hat is the estimated distribution, 
%       n_hat is the estimated number of mutations
%       period is the estimated pattern length
%       resnorm is the residual norm of the optimization problem
%
%   USAGE 2:
%   [q_hat, n_hat, period, resnorm] = SMTR(s,d) estimates the distribution
%   for the mutations in s assuming that the pattern length is d

% Written by Farzad Farnoud, farzad@virginia.edu, 2018

function [q_hat, M_hat, period, resnorm] = smtr(s,period,K,rho_thr)
%% Initialization
n = length(s);
rho= get_autocorr(s,'linear',floor(n/2)); % get autocorrelation with lag <=n/2
[maxrho,maxrho_ix] = max(rho);
if nargin == 4
    if maxrho < rho_thr
        q_hat = nan;
        M_hat = nan;
        period = nan;
        resnorm = nan;
        return
    end
end

if nargin<=1 || period<1
	period = maxrho_ix;
end

if n<2*period
    % disp('Avoiding copy number less than 2 is recommended!')
    q_hat = [1 0];
    M_hat = 0;
    resnorm = nan;
elseif n<=3*period
    q_hat(1) = 0;
    for i = 1:period
        q_hat(1) = q_hat(1) + numel(unique(s(i:period:end))) - 1;
    end
    q_hat(2) = floor((n-period)/period);
    q_hat(1) = q_hat(1)*(q_hat(2)+1)/q_hat(2);
    M_hat = sum(q_hat);
    q_hat = q_hat / M_hat;
    resnorm = nan;
else
    maxr = max([5*maxrho_ix,10*period]);
    maxr = min([maxr length(rho)]);
    maxi = maxr;
    if nargin>=3
        maxi = min([K*period,length(rho)]);
        maxr = maxi;
    end
    %% Estimation
    [q_hat, resnorm] = tdpm_est_rhoKd4(rho,maxr,maxi,period);
    expected_dup_length = period*sum((0:length(q_hat)-1)*q_hat(:));
    M_hat = (length(s)-period)/expected_dup_length;
    q_hat = q_hat';
    if M_hat > length(s)
        disp('Too many mutations!')
    end
end

% Estimate the parametres of a circular system with a mix of tandem and
% point mutations. The function assumes  K is the largest i s.t. q_i > 0.
% rho(i) is the autocorrelation function. The number of equations used
% equals the (length of rho).
% rho(1) in input: rho at lag 1
% rho(1) in code: rho at lag 0
function [qd, resnorm] = tdpm_est_rhoKd4(rho,maxr,maxi,d)
C = zeros(maxr,maxi+1); % second index should get +1
% r = 1,2,...,maxr (=\hat m-1)
% i = 0,1,...,maxi (<=\hat m-1 + maxr+1)
rho = [1 rho];
for r = 1 : maxr
    C(r,0+1) = 2/3 + (r-8/3)*rho(r+1);
    for i = 1 : maxi
        C(r,i+1) = r * rho(abs(i-r)+1);
    end
end
Cd = C(d:d:maxr,:);
Cd = Cd(:,1+(0:d:maxi));
rhod = (d:d:maxr).*rho(1+(d:d:maxr));
if numel(rhod)==0
    qd = 1;
    resnorm = nan;
    return
end
q_dims = size(Cd,2);
%ub = [ones(min(4,q_dims),1); zeros(q_dims-4,1)]; % set the number of nonzero elements in q
A = -d*(0:q_dims-1);
b = -1;
Aeq = ones(1,size(Cd,2));
beq = 1;
lb = zeros(size(Cd,2),1);
ub = [];
x0 = [0; ones(size(Cd,2)-1,1)/(size(Cd,2)-1)];
options = optimoptions('lsqlin','Algorithm','interior-point','Display','none');

[qd, resnorm] = lsqlin(Cd,rhod,A,b,Aeq,beq,lb,ub,x0,options);

function y = get_autocorr(s,mode,max_r)

if isa(s,'char')
    s = lower(s);
end
n = length(s);
if nargin<3
    max_r = n - 1;
end

if strcmpi(mode,'linear')
    y = zeros(1,max(max_r));
    for r = 1:max_r
        y(r) = sum(s(1:n-r)==s(r+1:n))/(n-r);
    end
end

if strcmpi(mode,'circular')
    y = zeros(1,max_r);
    for r = 1:max_r
        y(r) = sum(s==circshift(s,r,2))/n;
    end
end